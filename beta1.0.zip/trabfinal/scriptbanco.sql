use trabfinal;

drop database trabfinal;


insert into perfil values ("Administrador");
insert into perfil values ("Gerente");
insert into perfil values ("Usuario");


insert into usuarios values ("111.111.111-11","Danilo Pereira",md5("123"),"Administrador");
insert into usuarios values ("222.222.222-22","Crisostomo",md5("12"),"usuario");
insert into usuarios values ("333.333.333-33","Joaquim",md5("12"),"usuario");


select * from usuarios;
select * from produto;	


delete from usuarios where cpf="111.111.111-11";
delete from usuarios where cpf="222.222.222-22";
delete from usuarios where cpf="333.333.333-33";


